package com.ruoyi.framework.tenant.mybatis;

 import com.ruoyi.common.exception.ServiceException;
 import com.ruoyi.common.tenant.TenantContextHolder;
 import net.sf.jsqlparser.JSQLParserException;
 import net.sf.jsqlparser.expression.Expression;
 import net.sf.jsqlparser.expression.LongValue;
 import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
 import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
 import net.sf.jsqlparser.parser.CCJSqlParserUtil;
 import net.sf.jsqlparser.schema.Column;
 import net.sf.jsqlparser.schema.Table;
 import net.sf.jsqlparser.statement.Statement;
 import net.sf.jsqlparser.statement.delete.Delete;
 import net.sf.jsqlparser.statement.insert.Insert;
 import net.sf.jsqlparser.statement.select.FromItem;
 import net.sf.jsqlparser.statement.select.Join;
 import net.sf.jsqlparser.statement.select.ParenthesedSelect;
 import net.sf.jsqlparser.statement.select.PlainSelect;
 import net.sf.jsqlparser.statement.select.Select;
 import net.sf.jsqlparser.statement.update.Update;
 import org.apache.ibatis.executor.statement.StatementHandler;
 import org.apache.ibatis.plugin.*;
        import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;

 import java.lang.reflect.Field;
 import java.lang.reflect.Method;
 import java.sql.Connection;
 import java.util.ArrayList;
 import java.util.List;

/**
 - * 多租户 SQL 改写拦截器（JSqlParser 4.9 适配版）
 + * 多租户 SQL 改写拦截器（JSqlParser 4.9 适配版，修复 Join 重复 ON）
 *
 * 关键点：
 * - SELECT：主表 tenant 条件加到 WHERE；JOIN 表 tenant 条件加到 ON（保持 LEFT JOIN 语义）
 * - PageHelper count：FROM (subquery) table_count，需下钻到子查询内部改写
 - * - INSERT：补 tenant_id 列 + values（由 TenantSqlInsertValueAppender 处理 values 部分）
 + * - INSERT：补 tenant_id 列 + values（由 TenantSqlInsertValueAppender 处理 values 部分）
 * - UPDATE/DELETE：where 追加 tenant 条件
 *
 * 修复：
 * - JSqlParser 4.9 没有 SubSelect：使用 ParenthesedSelect
 - * - Join 在 4.9 可能同时维护 onExpression & onExpressions：必须兼容处理，否则会出现重复 ON 语法错误
 - * - Insert columns 在 4.9 可能是 ExpressionList<Column>：必须兼容追加
 + * - Join 在 4.9 可能同时维护 onExpression & onExpressions：必须强制清理 onExpressions，否则会出现重复 ON
 + * - Insert columns 在 4.9 可能是 ExpressionList<Column>：必须兼容追加
 */
@Intercepts({
        @Signature(type = StatementHandler.class, method = "prepare", args = {Connection.class, Integer.class})
})
public class TenantSqlInterceptor implements Interceptor {

    private static final Logger log = LoggerFactory.getLogger(TenantSqlInterceptor.class);

    private static final String TENANT_COLUMN = "tenant_id";

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        StatementHandler handler = (StatementHandler) invocation.getTarget();

        Long tenantId = TenantContextHolder.getTenantId();
        // tenantId==0 可作为平台管理员/平台租户（按需使用），这里默认不隔离
        if (tenantId == null || tenantId == 0L) {
            return invocation.proceed();
        }

        String originalSql = handler.getBoundSql().getSql();
        if (originalSql == null) {
            return invocation.proceed();
        }

        try {
            String newSql = rewriteSql(originalSql, tenantId);
            if (newSql != null && !newSql.equals(originalSql)) {
                setField(handler.getBoundSql(), "sql", newSql);
            }
        } catch (Exception ex) {
            // 解析失败：不能永久放过
            // 对“需要隔离”的 SQL 直接 fail-fast，避免跨租户数据泄露
            if (TenantSqlTableResolver.sqlLikelyNeedTenant(originalSql)) {
                log.error("Tenant SQL parse failed (fail-fast). tenantId={}, sql={}", tenantId, originalSql, ex);
                throw new ServiceException("多租户 SQL 解析失败（已阻止执行），请修复 SQL： " + ex.getMessage());
            }
            // 对不隔离的 SQL：记录日志后放过
            log.warn("Tenant SQL parse failed (ignored). tenantId={}, sql={}", tenantId, originalSql, ex);
            return invocation.proceed();
        }

        return invocation.proceed();
    }

    private String rewriteSql(String sql, Long tenantId) throws JSQLParserException {
        Statement stmt = CCJSqlParserUtil.parse(sql);

        if (stmt instanceof Select) {
            Select select = (Select) stmt;
            return rewriteSelect(select, tenantId, sql);
        }

        if (stmt instanceof Update) {
            Update update = (Update) stmt;
            String table = (update.getTable() != null) ? update.getTable().getName() : null;
            if (!TenantSqlTableResolver.needTenant(table)) return sql;

            Expression cond = eqTenant(updateAliasOrTable(update) + "." + TENANT_COLUMN, tenantId);
            Expression newWhere = (update.getWhere() == null) ? cond : new AndExpression(update.getWhere(), cond);
            update.setWhere(simplifyAnd(newWhere));
            return stmt.toString();
        }

        if (stmt instanceof Delete) {
            Delete del = (Delete) stmt;
            String table = (del.getTable() != null) ? del.getTable().getName() : null;
            if (!TenantSqlTableResolver.needTenant(table)) return sql;

            Expression cond = eqTenant(deleteAliasOrTable(del) + "." + TENANT_COLUMN, tenantId);
            Expression newWhere = (del.getWhere() == null) ? cond : new AndExpression(del.getWhere(), cond);
            del.setWhere(simplifyAnd(newWhere));
            return stmt.toString();
        }

        if (stmt instanceof Insert) {
            Insert ins = (Insert) stmt;
            String table = (ins.getTable() != null) ? ins.getTable().getName() : null;
            if (!TenantSqlTableResolver.needTenant(table)) return sql;

            // insert-select 不在这里处理（避免误改）
            if (ins.getSelect() != null) {
                return sql;
            }

            // 已经显式写了 tenant_id，则不处理
            if (insertHasTenantColumn(ins)) {
                return sql;
            }

            // 追加 tenant_id 列（兼容 4.9 ExpressionList<Column> 与旧版 List<Column>）
            if (appendInsertTenantColumn(ins)) {
                // values(...) 的追加由 TenantSqlInsertValueAppender 内部做 4.9 兼容
                TenantSqlInsertValueAppender.appendTenantValue(ins, tenantId);
                return stmt.toString();
            }

            // 没写列清单：insert into t values(...)，不安全，默认不处理
            return sql;
        }

        return sql;
    }

    private String rewriteSelect(Select select, Long tenantId, String originalSql) {
        Object body = getSelectBodyCompat(select);
        if (body instanceof PlainSelect) {
            PlainSelect ps = (PlainSelect) body;
            boolean changed = applyTenantToPlainSelect(ps, tenantId);
            return changed ? select.toString() : originalSql;
        }
        return originalSql;
    }

    private boolean applyTenantToPlainSelect(PlainSelect ps, Long tenantId) {
        if (ps == null) return false;

        boolean changed = false;

        FromItem from = ps.getFromItem();
        String mainTable = TenantSqlTableResolver.resolveMainTableName(from);

        // PageHelper count / 派生表：FROM ( ... ) table_count 需要下钻
        PlainSelect derived = extractPlainSelect(from);
        if (mainTable == null && derived != null) {
            return applyTenantToPlainSelect(derived, tenantId);
        }

        // 主表：WHERE 追加 tenant 条件
        if (mainTable != null && TenantSqlTableResolver.needTenant(mainTable)) {
            String qualifier = tableAliasOrTable(ps, mainTable);
            Expression cond = eqTenant(qualifier + "." + TENANT_COLUMN, tenantId);
            Expression newWhere = (ps.getWhere() == null) ? cond : new AndExpression(ps.getWhere(), cond);
            ps.setWhere(simplifyAnd(newWhere));
            changed = true;
        }

        // JOIN：tenant 条件必须放到 ON（保持 LEFT JOIN 语义）
        List<Join> joins = ps.getJoins();
        if (joins != null && !joins.isEmpty()) {
            for (Join join : joins) {
                FromItem right = join.getRightItem();
                if (right == null) continue;

                // JOIN (subselect) 下钻处理
                PlainSelect joinDerived = extractPlainSelect(right);
                if (joinDerived != null) {
                    changed = applyTenantToPlainSelect(joinDerived, tenantId) || changed;
                    continue;
                }

                String joinTable = TenantSqlTableResolver.resolveMainTableName(right);
                if (joinTable == null || !TenantSqlTableResolver.needTenant(joinTable)) {
                    continue;
                }

                String joinQualifier = joinAliasOrTable(join);
                if (joinQualifier == null || joinQualifier.trim().isEmpty()) {
                    continue;
                }

                Expression joinCond = eqTenant(joinQualifier + "." + TENANT_COLUMN, tenantId);

                // ✅ 关键：兼容 4.9，必须清掉 onExpressions，否则会出现 “... ON ... ON ...”
                appendTenantToJoinOnCompat(join, joinCond);
                changed = true;
            }
        }

        return changed;
    }

    /**
     * ✅ JSqlParser 4.9 Join ON 兼容：最终只保留一个 ON，且一定能输出 ON
     * 关键：4.9 的 Join.toString() 多数情况下使用 onExpressions(List) 来渲染 ON
     */
    @SuppressWarnings("unchecked")
    private void appendTenantToJoinOnCompat(Join join, Expression tenantCond) {
        if (join == null || tenantCond == null) return;

        // 1) 先从 join 里拿到“原始 ON”（优先用 onExpressions，其次用 onExpression）
        List<Expression> originOnList = null;

        Object onExprsObj = invokeNoArg(join, "getOnExpressions");
        if (onExprsObj instanceof List) {
            originOnList = (List<Expression>) onExprsObj;
        }

        Expression baseOn = null;

        if (originOnList != null && !originOnList.isEmpty()) {
            // 取第一个非空 ON
            for (Expression e : originOnList) {
                if (e == null) continue;
                if (containsTenant(e)) return; // 已有 tenant 条件，直接不动
                baseOn = e;
                break;
            }
        } else {
            Expression singleOn = join.getOnExpression();
            if (singleOn != null) {
                if (containsTenant(singleOn)) return;
                baseOn = singleOn;
            }
        }

        // 如果原 SQL 本来就没有 ON（理论上 LEFT JOIN 必须有 ON），这里不强行补，避免生成语义错误 SQL
        if (baseOn == null) {
            return;
        }

        // 2) 合并 tenant 条件
        Expression merged = simplifyAnd(new AndExpression(baseOn, tenantCond));

        // 3) ✅ 最终写回：只用 onExpressions 输出 ON（避免重复 ON / 丢失 ON）
        setJoinOnExpressionsSingleton(join, merged);

        // 4) 清掉 onExpression（避免某些版本同时输出两套）
        try {
            join.setOnExpression(null);
        } catch (Exception ignore) {}
    }

    /**
     * 把 Join 的 ON 设置为 onExpressions = [merged]
     * 兼容：如果 setOnExpressions 不存在，则降级到 setOnExpression
     */
    private void setJoinOnExpressionsSingleton(Join join, Expression merged) {
        if (join == null) return;

        List<Expression> one = new ArrayList<>();
        one.add(merged);

        // 优先用 setOnExpressions(List)
        try {
            Method m = join.getClass().getMethod("setOnExpressions", List.class);
            m.invoke(join, one);
            // 反射兜底：把内部可能的 onExpressions 字段也指向这个 one（防止 set 方法没生效）
            forceReplaceJoinOnExpressionsField(join, one);
            return;
        } catch (Exception ignore) {
            // fallback
        }

        // 降级：老结构用 onExpression
        join.setOnExpression(merged);
    }

    private void forceReplaceJoinOnExpressionsField(Join join, List<Expression> one) {
        try {
            Class<?> c = join.getClass();
            while (c != null && c != Object.class) {
                for (Field f : c.getDeclaredFields()) {
                    if (!List.class.isAssignableFrom(f.getType())) continue;
                    String name = f.getName();
                    if (name == null) continue;
                    String n = name.toLowerCase();
                    if (n.contains("on") && n.contains("expression")) {
                        f.setAccessible(true);
                        f.set(join, one);
                    }
                }
                c = c.getSuperclass();
            }
        } catch (Exception ignore) {
        }
    }



    private void forceClearJoinOnExpressions(Join join) {
        if (join == null) return;

        // 4.1 先尝试 setter（若存在）
        try {
            Method m = join.getClass().getMethod("setOnExpressions", List.class);
            m.invoke(join, new ArrayList<>());
        } catch (Exception ignore) {
        }

        // 4.2 反射兜底：清空所有可能的 onExpressions 字段
        try {
            Class<?> c = join.getClass();
            while (c != null && c != Object.class) {
                for (Field f : c.getDeclaredFields()) {
                    String name = f.getName();
                    if (name == null) continue;
                    if (List.class.isAssignableFrom(f.getType())
                            && name.toLowerCase().contains("on")
                            && name.toLowerCase().contains("expression")) {
                        f.setAccessible(true);
                        Object v = f.get(join);
                        if (v instanceof List) {
                            ((List<?>) v).clear();
                        } else {
                            f.set(join, null);
                        }
                    }
                }
                c = c.getSuperclass();
            }
        } catch (Exception ignore) {
        }
    }

    private boolean containsTenant(Expression exp) {
        if (exp == null) return false;
        String s = exp.toString().toLowerCase();
        return s.contains("." + TENANT_COLUMN) || s.contains(" " + TENANT_COLUMN + " ");
    }

    /**
     * 从 FromItem 中提取子查询内部的 PlainSelect（最常见的括号子查询）。
     *
     * JSqlParser 4.9+：子查询 FromItem 通常为 ParenthesedSelect。
     */
    private PlainSelect extractPlainSelect(FromItem fromItem) {
        if (fromItem == null) return null;

        if (fromItem instanceof ParenthesedSelect) {
            ParenthesedSelect ps = (ParenthesedSelect) fromItem;
            if (ps.getSelect() == null) return null;
            Object body = getSelectBodyCompat(ps.getSelect());
            return (body instanceof PlainSelect) ? (PlainSelect) body : null;
        }

        // 反射兜底
        try {
            Object selectObj = null;
            try {
                selectObj = fromItem.getClass().getMethod("getSelect").invoke(fromItem);
            } catch (NoSuchMethodException ignore) {
                try {
                    selectObj = fromItem.getClass().getMethod("getSubSelect").invoke(fromItem);
                } catch (NoSuchMethodException ignore2) {
                }
            }

            if (selectObj instanceof Select) {
                Object body = getSelectBodyCompat(selectObj);
                return (body instanceof PlainSelect) ? (PlainSelect) body : null;
            }
        } catch (Exception ignore) {
        }

        return null;
    }

    private EqualsTo eqTenant(String qualifiedColumn, Long tenantId) {
        EqualsTo eq = new EqualsTo();
        eq.setLeftExpression(new Column(qualifiedColumn));
        eq.setRightExpression(new LongValue(tenantId));
        return eq;
    }

    private Object getSelectBodyCompat(Object selectObj) {
        if (selectObj == null) return null;
        try {
            return selectObj.getClass().getMethod("getSelectBody").invoke(selectObj);
        } catch (Exception e) {
            return null;
        }
    }

    private Expression simplifyAnd(Expression exp) {
        if (exp instanceof AndExpression) {
            AndExpression and = (AndExpression) exp;
            if (and.getLeftExpression() == null) return and.getRightExpression();
        }
        return exp;
    }

    private String tableAliasOrTable(PlainSelect ps, String tableName) {
        if (ps.getFromItem() != null && ps.getFromItem().getAlias() != null) {
            return ps.getFromItem().getAlias().getName();
        }
        return tableName;
    }

    private String joinAliasOrTable(Join join) {
        if (join == null || join.getRightItem() == null) {
            return null;
        }
        FromItem right = join.getRightItem();
        if (right.getAlias() != null) {
            return right.getAlias().getName();
        }
        if (right instanceof Table) {
            return ((Table) right).getName();
        }
        return null;
    }

    private String updateAliasOrTable(Update update) {
        if (update.getTable() != null && update.getTable().getAlias() != null) {
            return update.getTable().getAlias().getName();
        }
        return update.getTable() != null ? update.getTable().getName() : "";
    }

    private String deleteAliasOrTable(Delete del) {
        if (del.getTable() != null && del.getTable().getAlias() != null) {
            return del.getTable().getAlias().getName();
        }
        return del.getTable() != null ? del.getTable().getName() : "";
    }

    // -------- Insert columns 兼容（4.9: ExpressionList<Column>）--------

    private boolean insertHasTenantColumn(Insert ins) {
        Object colsObj = invokeNoArg(ins, "getColumns");
        if (colsObj == null) return false;

        // 4.9: ExpressionList<Column> -> getExpressions()
        if (isExpressionList(colsObj)) {
            Object exprs = invokeNoArg(colsObj, "getExpressions");
            if (exprs instanceof List) {
                for (Object o : (List<?>) exprs) {
                    if (o instanceof Column) {
                        if (TENANT_COLUMN.equalsIgnoreCase(((Column) o).getColumnName())) return true;
                    }
                }
            }
            return false;
        }

        // 旧版: List<Column>
        if (colsObj instanceof List) {
            for (Object o : (List<?>) colsObj) {
                if (o instanceof Column) {
                    if (TENANT_COLUMN.equalsIgnoreCase(((Column) o).getColumnName())) return true;
                }
            }
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private boolean appendInsertTenantColumn(Insert ins) {
        Object colsObj = invokeNoArg(ins, "getColumns");
        if (colsObj == null) {
            return false;
        }

        // 4.9: ExpressionList<Column>
        if (isExpressionList(colsObj)) {
            Object exprs = invokeNoArg(colsObj, "getExpressions");
            if (exprs instanceof List) {
                List<Column> cols = new ArrayList<>((List<Column>) exprs);
                cols.add(new Column(TENANT_COLUMN));
                invokeSetter(colsObj, "setExpressions", List.class, cols);
                invokeSetter(ins, "setColumns", colsObj.getClass(), colsObj);
                return true;
            }
            return false;
        }

        // 旧版: List<Column>
        if (colsObj instanceof List) {
            List<Column> cols = new ArrayList<>((List<Column>) colsObj);
            cols.add(new Column(TENANT_COLUMN));
            invokeSetter(ins, "setColumns", List.class, cols);
            return true;
        }
        return false;
    }

    private boolean isExpressionList(Object obj) {
        return obj != null && "net.sf.jsqlparser.expression.operators.relational.ExpressionList"
                .equals(obj.getClass().getName());
    }

    // -------- reflection helpers --------

    private static Object invokeNoArg(Object target, String method) {
        try {
            Method m = target.getClass().getMethod(method);
            return m.invoke(target);
        } catch (Exception e) {
            return null;
        }
    }

    private static void invokeSetter(Object target, String method, Class<?> paramType, Object arg) {
        try {
            Method m = target.getClass().getMethod(method, paramType);
            m.invoke(target, arg);
        } catch (Exception ignore) {
        }
    }

    private static void setField(Object target, String fieldName, Object value) throws Exception {
        Field f = target.getClass().getDeclaredField(fieldName);
        f.setAccessible(true);
        f.set(target, value);
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }
}